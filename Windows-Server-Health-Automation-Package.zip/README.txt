WINDOWS SERVER HEALTH AUTOMATION

Files
- Windows-Server-Health-Automation-Guide.pdf: printable setup and operations guide, including the full installer.
- Windows-Server-Health-Automation-Guide.docx: editable copy of the guide.
- Install-OpsHealth.ps1: complete installer to open in Windows PowerShell ISE.

Start
Read the guide, copy the .ps1 file to your target server, open Windows PowerShell ISE as administrator, open the file, review the schedule, and press F5.
Default: local report at 07:00 daily, task OpsHealth-Daily, account SYSTEM.
The package does not execute or deploy anything until you run it.

Validation
The files were checked for consistency. The script has not been executed on a Windows server in this preparation environment. Follow the guide to verify a scheduled SYSTEM run.
